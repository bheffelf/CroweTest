﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CroweAPI;
using System.Configuration;
using System.Collections.Specialized;

namespace HelloWorld_Crowe
{
    public partial class Form1 : Form
    {
        string dbName = "";
        string outputType = "Form";

        public Form1()
        {
            InitializeComponent();
            dbName = ConfigurationManager.AppSettings.Get("DatabaseName");
            outputType = ConfigurationManager.AppSettings.Get("OutputType");
        }

        private void button1_MouseClick(object sender, MouseEventArgs e)
        {
            CroweAPI.DatabaseCommunicator databaseCommunicator = new CroweAPI.DatabaseCommunicator();

            CroweAPI.MobileCommunicator mobileCommunicator = new CroweAPI.MobileCommunicator();

            CroweAPI.WebInterfacer webInterfacer = new CroweAPI.WebInterfacer();

            if (databaseCommunicator.ConnectToDatabase(dbName))
            {
                MessageBox.Show(string.Format("Connection Successful to Database {0}!",dbName));
            }

            if (outputType.Equals("Form"))
                MessageBox.Show("Hello World!");

            if (outputType.Equals("Console"))
                Console.WriteLine("HelloWorld!");
        }
    }
}
