﻿using System;

namespace CroweAPI
{

    public class DatabaseCommunicator
    {
        public bool ConnectToDatabase(string DbName)
        {

            return true;
        }
    }

    public class MobileCommunicator
    {


    }

    public class WebInterfacer
    {



    }
}
